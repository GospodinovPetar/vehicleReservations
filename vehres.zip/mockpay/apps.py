from django.apps import AppConfig


class MockpayConfig(AppConfig):
    name = "mockpay"
